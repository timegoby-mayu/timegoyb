package com.paasit.pai.core.sql.dto.demo;

import java.io.Serializable;

import lombok.Data;

/**
 * 描述:[com_paasit_pai_core_demo][人员]插入方法的SQLOutputDTO
 * @version: 0_1
 * @author: AutoGenerate
 * @date: 2017-10-11 16:07:48
 */
@Data
public class DemoF01SQL01OM01 implements Serializable {

    private static final long serialVersionUID = 1495675280489558317L;
}
