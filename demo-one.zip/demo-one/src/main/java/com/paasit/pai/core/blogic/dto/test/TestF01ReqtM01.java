/**
 * 
 */
package com.paasit.pai.core.blogic.dto.test;

import lombok.Data;

/**
 * 描述:
 * @version: 0_1
 * @author: 鲍玉宇
 * @date: 2018年3月27日 下午6:44:19
 */
@Data
public class TestF01ReqtM01 {

}
